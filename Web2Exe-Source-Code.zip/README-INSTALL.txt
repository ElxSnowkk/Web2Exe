WEB2EXE - INSTALAÇÃO

1) Extraia o ZIP.
2) Execute:
   bash install.sh

No Termux, o comando exige o modo explicitamente:
   web2exe --termux --chroot
   web2exe --termux --proot

No Linux:
   web2exe --linux

O assistente pede:
- nome do app
- ID
- nome do EXE
- URL
- pasta de instalação do Windows
- caminho da logo PNG
- ICO opcional

Cada projeto é criado em ./web2exe-projects/<id> e então o build é iniciado.


CLI:
  web2exe --help
  web2exe --version

No Termux, o Web2Exe detecta o ambiente e exige o modo explícito --chroot ou --proot.
