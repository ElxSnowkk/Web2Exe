#!/usr/bin/env bash
set -e
WEB2EXE_VERSION="1.0.0"
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC="$BASE_DIR/template"

if [ ! -d "$SRC" ]; then
  echo "[ERR] template não encontrado: $SRC" >&2
  exit 1
fi

if [ -n "${PREFIX:-}" ] && [ -d "$PREFIX/bin" ] && [[ "$PREFIX" == *com.termux* ]]; then
  DEST="$PREFIX/share/web2exe"
  BIN="$PREFIX/bin"
else
  DEST="${XDG_DATA_HOME:-$HOME/.local/share}/web2exe"
  BIN="${XDG_BIN_HOME:-$HOME/.local/bin}"
fi

mkdir -p "$DEST" "$BIN"
rm -rf "$DEST/template"
cp -a "$SRC" "$DEST/template"

cat > "$BIN/web2exe" <<'WRAP'
#!/usr/bin/env bash
set -euo pipefail

DATA="${XDG_DATA_HOME:-$HOME/.local/share}/web2exe"
if [ -n "${PREFIX:-}" ] && [ -d "$PREFIX/share/web2exe" ] && [[ "$PREFIX" == *com.termux* ]]; then
  DATA="$PREFIX/share/web2exe"
fi
TEMPLATE="$DATA/template"

c(){ printf '\033[%sm%s\033[0m\n' "$1" "$2"; }
info(){ c '1;36' "[INFO] $*"; }
ok(){ c '1;32' "[ OK ] $*"; }
warn(){ c '1;33' "[WARN] $*"; }
err(){ c '1;31' "[ERR ] $*"; }

usage(){
  cat <<USAGE
web2exe ${WEB2EXE_VERSION} — Generic WebView2 App Builder

USAGE
Termux (modo obrigatório):
  web2exe --termux --chroot
  web2exe --termux --proot

Linux:
  web2exe --linux

Informações:
  web2exe --help
  web2exe --version

O build universal gera automaticamente x86, x64 e ARM64,
com EXE + DLLs por arquitetura dentro do instalador universal.
Cada execução abre um assistente para nome, site, logo PNG e demais configurações.
USAGE
}

[ -d "$TEMPLATE" ] || { err "Template não encontrado em $TEMPLATE"; exit 1; }

TERMUX=0
MODE=""
NATIVE=0
IS_TERMUX=0
if [ -n "${PREFIX:-}" ] && [[ "$PREFIX" == *com.termux* ]] && [ -d "$PREFIX" ]; then
  IS_TERMUX=1
elif [ -d /data/data/com.termux/files/usr ]; then
  IS_TERMUX=1
fi

case "${1:-}" in
  --termux)
    TERMUX=1
    MODE="${2:-}"
    case "$MODE" in --chroot|--proot) ;; *) err "No Termux você DEVE especificar --chroot ou --proot."; usage; exit 2;; esac
    ;;
  --linux) MODE="--linux" ;;
  --version|-V) printf 'web2exe %s\n' "$WEB2EXE_VERSION"; exit 0 ;;
  --help|-h|"") usage; exit 0 ;;
  *) err "Argumento inválido: $1"; usage; exit 2 ;;
esac

if [ "$IS_TERMUX" = 1 ]; then
  printf '\n\033[1;33m[ TERMUX ] TERMUX Detectado, Trocando Modo de build\033[0m\n'
  if [ "$TERMUX" = 0 ]; then
    warn "No Termux, use explicitamente: web2exe --termux --chroot ou web2exe --termux --proot"
    exit 2
  fi
fi

# Detect terminal language and let the user confirm/select it.
LOCALE="${LC_ALL:-${LANG:-${LC_MESSAGES:-}}}"
case "${LOCALE,,}" in
  pt_br*|pt-*) DETECTED_LANG="pt" ;;
  es*|ca*) DETECTED_LANG="es" ;;
  *) DETECTED_LANG="en" ;;
esac
case "$DETECTED_LANG" in
  pt) DETECTED_NAME="Português (Brasil)"; DEFAULT_LANG=1 ;;
  es) DETECTED_NAME="Español"; DEFAULT_LANG=3 ;;
  *) DETECTED_NAME="English"; DEFAULT_LANG=2 ;;
esac
printf '\n\033[1;36mDetected terminal language:\033[0m %s\n' "$DETECTED_NAME"
printf '1) Português (Brasil)\n2) English\n3) Español\n'
printf 'Language [1/2/3, Enter=%s]: ' "$DEFAULT_LANG"
read -r LANG_CHOICE
case "$LANG_CHOICE" in
  1) LANG_CODE=pt;; 2) LANG_CODE=en;; 3) LANG_CODE=es;; "") LANG_CODE="$DETECTED_LANG";; *) LANG_CODE="$DETECTED_LANG";;
esac
if [ "$LANG_CODE" = pt ]; then
  L_NAME='Nome do aplicativo'; L_ID='ID do aplicativo (ex.: meu-app)'; L_EXE='Nome do EXE sem .exe'; L_URL='URL do site'; L_INSTALL='Nome da pasta de instalação no Windows'; L_LOGO='Caminho da logo PNG (obrigatório)'; L_ICON='Caminho do .ico (opcional; Enter para usar assets/app.ico)'; L_REQ='A logo PNG é obrigatória.'; L_MISSING='Logo não encontrada'; L_CREATED='Projeto criado'; L_MODE='Modo selecionado'; L_DONE='web2exe concluído.'
elif [ "$LANG_CODE" = es ]; then
  L_NAME='Nombre de la aplicación'; L_ID='ID de la aplicación (ej.: mi-app)'; L_EXE='Nombre del EXE sin .exe'; L_URL='URL del sitio'; L_INSTALL='Nombre de la carpeta de instalación en Windows'; L_LOGO='Ruta del logo PNG (obligatorio)'; L_ICON='Ruta del .ico (opcional; Enter para usar assets/app.ico)'; L_REQ='El logo PNG es obligatorio.'; L_MISSING='Logo no encontrado'; L_CREATED='Proyecto creado'; L_MODE='Modo seleccionado'; L_DONE='web2exe terminado.'
else
  L_NAME='Application name'; L_ID='Application ID (e.g. my-app)'; L_EXE='EXE name without .exe'; L_URL='Website URL'; L_INSTALL='Windows installation folder name'; L_LOGO='PNG logo path (required)'; L_ICON='.ico path (optional; Enter to use assets/app.ico)'; L_REQ='The PNG logo is required.'; L_MISSING='Logo not found'; L_CREATED='Project created'; L_MODE='Selected mode'; L_DONE='web2exe finished.'
fi
printf '\n\033[1;35m╔════════════════════════════════════════════╗\033[0m\n'
printf '\033[1;35m║        WEB2EXE • PROJECT WIZARD           ║\033[0m\n'
printf '\033[1;35m╚════════════════════════════════════════════╝\033[0m\n\n'

ask(){
  local label="$1" default="${2:-}" value
  if [ -n "$default" ]; then
    printf '\033[1;37m%s\033[0m [%s]: ' "$label" "$default"; read -r value; value="${value:-$default}"
  else
    printf '\033[1;37m%s\033[0m: ' "$label"; read -r value
  fi
  printf '%s' "$value"
}

APP_NAME="$(ask "$L_NAME" 'Meu App')"
APP_ID="$(ask "$L_ID" 'meu-app')"
APP_EXE="$(ask "$L_EXE" "$APP_ID")"
APP_URL="$(ask "$L_URL" 'https://example.com')"
INSTALL_DIR="$(ask "$L_INSTALL" "$APP_NAME")"
LOGO=""
while [ -z "$LOGO" ]; do
  LOGO="$(ask "$L_LOGO" '')"
  [ -n "$LOGO" ] || warn "$L_REQ"
done
ICON="$(ask "$L_ICON" '')"

if [ ! -f "$LOGO" ]; then err "$L_MISSING: $LOGO"; exit 1; fi
case "$LOGO" in *.png|*.PNG) ;; *) warn 'O arquivo informado não parece ser PNG.';; esac

WORK_ROOT="$(pwd)/web2exe-projects"
mkdir -p "$WORK_ROOT"
PROJECT="$WORK_ROOT/$APP_ID"
if [ -e "$PROJECT" ]; then
  n=2; while [ -e "${PROJECT}-$n" ]; do n=$((n+1)); done
  PROJECT="${PROJECT}-$n"
fi
cp -a "$TEMPLATE" "$PROJECT"
rm -rf "$PROJECT/.git" "$PROJECT/scripts/__pycache__"
mkdir -p "$PROJECT/assets"
cp "$LOGO" "$PROJECT/assets/logo.png"
if [ -n "$ICON" ]; then
  if [ -f "$ICON" ]; then cp "$ICON" "$PROJECT/assets/app.ico"; else warn "ICO não encontrado; continuando sem ele."; fi
fi

python3 - "$PROJECT/build.prop" "$APP_NAME" "$APP_ID" "$APP_EXE" "$APP_URL" "$INSTALL_DIR" <<'PY'
import sys, pathlib
p=pathlib.Path(sys.argv[1])
vals={'APP_NAME':sys.argv[2],'APP_ID':sys.argv[3],'APP_EXE_NAME':sys.argv[4],'APP_URL':sys.argv[5],'INSTALL_DIR':sys.argv[6]}
lines=[]
for line in p.read_text().splitlines():
    k=line.split('=',1)[0].strip() if '=' in line else ''
    if k in vals: lines.append(f'{k}="{vals[k].replace(chr(34), chr(92)+chr(34))}"')
    else: lines.append(line)
# Ensure expected keys exist.
for k,v in vals.items():
    if not any(x.startswith(k+'=') for x in lines): lines.append(f'{k}="{v}"')
p.write_text('\n'.join(lines)+'\n')
PY

chmod +x "$PROJECT/build.sh" "$PROJECT/linux-build.sh" "$PROJECT/termux-proot/proot.sh" "$PROJECT/scripts"/*.sh
ok "$L_CREATED: $PROJECT"
info "$L_MODE: $MODE"

if [ "$TERMUX" = 1 ]; then
  if [ "$MODE" = "--chroot" ]; then
    bash "$PROJECT/termux-proot/proot.sh" chroot
  else
    bash "$PROJECT/termux-proot/proot.sh" proot
  fi
else
  bash "$PROJECT/linux-build.sh"
fi

ok "$L_DONE"
WRAP
chmod +x "$BIN/web2exe"

# Ensure the Linux user can invoke it without changing shell startup files.
if [[ ":$PATH:" != *":$BIN:"* ]]; then
  echo "[WARN] $BIN não está no PATH desta sessão."
  echo "Adicione: export PATH=\"$BIN:\$PATH\""
fi

echo "[ OK ] web2exe instalado em: $BIN/web2exe"
echo
echo "Termux:"
echo "  web2exe --termux --chroot"
echo "  web2exe --termux --proot"
echo
echo "Linux:"
echo "  web2exe --linux"
