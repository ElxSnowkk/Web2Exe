#include <windows.h>
#include "WebView2.h"
#include "config.hpp"
#include "webview.hpp"
namespace {
HWND H=nullptr; ICoreWebView2Controller*C=nullptr; ICoreWebView2*V=nullptr;
struct E:ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler{ULONG r=1;HRESULT QueryInterface(REFIID i,void**p)override{if(!p)return E_POINTER;*p=nullptr;if(i==IID_IUnknown||i==IID_ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler){*p=this;AddRef();return S_OK;}return E_NOINTERFACE;}ULONG AddRef()override{return ++r;}ULONG Release()override{auto n=--r;if(!n)delete this;return n;}HRESULT Invoke(HRESULT,ICoreWebView2Environment*)override;};
struct K:ICoreWebView2CreateCoreWebView2ControllerCompletedHandler{ULONG r=1;HRESULT QueryInterface(REFIID i,void**p)override{if(!p)return E_POINTER;*p=nullptr;if(i==IID_IUnknown||i==IID_ICoreWebView2CreateCoreWebView2ControllerCompletedHandler){*p=this;AddRef();return S_OK;}return E_NOINTERFACE;}ULONG AddRef()override{return ++r;}ULONG Release()override{auto n=--r;if(!n)delete this;return n;}HRESULT Invoke(HRESULT z,ICoreWebView2Controller*x)override{if(FAILED(z)||!x)return z;x->AddRef();C=x;C->get_CoreWebView2(&V);RECT q{};GetClientRect(H,&q);C->put_Bounds(q);if(V)V->Navigate(Config::APP_URL);return S_OK;}};
HRESULT E::Invoke(HRESULT z,ICoreWebView2Environment*x){if(FAILED(z)||!x)return z;auto*k=new K;auto h=x->CreateCoreWebView2Controller(H,k);k->Release();return h;}
LRESULT CALLBACK W(HWND h,UINT m,WPARAM,LPARAM){if(m==WM_SIZE&&C){RECT q{};GetClientRect(h,&q);C->put_Bounds(q);}if(m==WM_DESTROY){if(V)V->Release();if(C)C->Release();PostQuitMessage(0);}return DefWindowProcW(h,m,0,0);}
}
namespace App{
bool Create(HINSTANCE h,int n){WNDCLASSEXW w{sizeof(w)};w.hInstance=h;w.lpfnWndProc=W;w.lpszClassName=L"GenericWV2";w.hCursor=LoadCursorW(nullptr,IDC_ARROW);RegisterClassExW(&w);H=CreateWindowExW(0,w.lpszClassName,Config::APP_NAME,WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,1280,800,nullptr,nullptr,h,nullptr);if(!H)return false;ShowWindow(H,n);auto*e=new E;auto z=CreateCoreWebView2EnvironmentWithOptions(nullptr,nullptr,nullptr,e);e->Release();return SUCCEEDED(z);}
int Run(){MSG m{};while(GetMessageW(&m,nullptr,0,0)>0){TranslateMessage(&m);DispatchMessageW(&m);}return(int)m.wParam;}}
