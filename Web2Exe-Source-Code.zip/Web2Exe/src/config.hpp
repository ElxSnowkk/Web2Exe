#pragma once
namespace Config { inline constexpr wchar_t APP_NAME[]=L"__APP_NAME__"; inline constexpr wchar_t APP_URL[]=L"__APP_URL__"; }
