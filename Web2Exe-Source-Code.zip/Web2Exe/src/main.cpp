#include <windows.h>
#include "webview.hpp"
int APIENTRY wWinMain(HINSTANCE h,HINSTANCE,PWSTR,int n){return App::Create(h,n)?App::Run():1;}
