#pragma once
#include <windows.h>
namespace App { bool Create(HINSTANCE,int); int Run(); }
