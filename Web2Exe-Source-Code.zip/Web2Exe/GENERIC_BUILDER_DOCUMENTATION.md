
---

# 30. Runtime LLVM-MinGW embutido no Setup

O Generic Builder agora trata as DLLs de runtime do LLVM-MinGW como parte do payload do aplicativo.

Durante o build de cada arquitetura, o script procura no toolchain:

```text
libc++.dll
libunwind.dll
libc++abi.dll
libwinpthread-1.dll
```

As que existirem são copiadas para:

```text
dist/x86/
dist/x64/
dist/arm64/
```

O instalador também detecta todos os `lib*.dll` presentes nesses diretórios e os embute no `Setup.exe` junto com:

```text
<APP_EXE_NAME>.exe
WebView2Loader.dll
```

Assim, a instalação final fica, por exemplo:

```text
C:\Program Files\Meu App\
├── MeuApp.exe
├── WebView2Loader.dll
├── libc++.dll
└── libunwind.dll
```

Isso corrige erros como:

```text
Library libc++.dll ... not found
Library libunwind.dll ... not found
status c0000135
```

O mecanismo continua separado por arquitetura: cada Windows recebe somente o payload nativo correspondente.

---

# Termux: CHROOT + PROOT

A entrada do Termux é agora única:

```bash
bash termux-proot/proot.sh
```

O modo `auto` tenta CHROOT primeiro e, se não estiver disponível, faz fallback automático para PROOT.

Para forçar CHROOT:

```bash
bash termux-proot/proot.sh chroot
```

Para forçar PROOT:

```bash
bash termux-proot/proot.sh proot
```

Não é necessário manter um `chroot.sh` separado.


### Build universal automático
O Web2Exe detecta a arquitetura do host apenas para escolher o pacote LLVM-MinGW compatível. O resultado é sempre universal: x86, x64 e ARM64. Não há opção para escolher arquitetura manualmente. O instalador universal embute o EXE e todas as DLLs de cada arquitetura e seleciona o conjunto correto no Windows.
