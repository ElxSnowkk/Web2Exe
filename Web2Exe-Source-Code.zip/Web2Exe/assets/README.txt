Put assets/logo.png here. Optionally put assets/app.ico here.
