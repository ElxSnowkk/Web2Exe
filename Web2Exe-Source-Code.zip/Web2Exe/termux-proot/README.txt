TERMUX - CHROOT + PROOT

Entrada única:
  bash termux-proot/proot.sh

O modo AUTO tenta CHROOT primeiro e cai automaticamente para PROOT.

Forçar CHROOT:
  bash termux-proot/proot.sh chroot

Forçar PROOT:
  bash termux-proot/proot.sh proot

O builder não exige root no modo PROOT.
