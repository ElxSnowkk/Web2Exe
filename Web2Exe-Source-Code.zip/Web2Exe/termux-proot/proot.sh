#!/data/data/com.termux/files/usr/bin/bash
# Generic WebView2 Builder - Termux launcher
# Modes: auto (default), chroot, proot
set -u
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
MODE="${1:-auto}"

c(){ printf '\033[%sm%s\033[0m\n' "$1" "$2"; }
info(){ c '1;36' "[INFO] $*"; }
ok(){ c '1;32' "[ OK ] $*"; }
warn(){ c '1;33' "[WARN] $*"; }
err(){ c '1;31' "[ERR ] $*"; }

if [ "$MODE" = "--help" ] || [ "$MODE" = "-h" ]; then
  cat <<HELP
Uso: bash termux-proot/proot.sh [modo]

Modos:
  auto    tenta chroot funcional; cai para PRoot automaticamente (padrão)
  chroot  força chroot/chroot-distro
  proot   força PRoot/proot-distro, sem root
HELP
  exit 0
fi

cd "$ROOT_DIR" || exit 1

run_build(){
  if [ -x "$ROOT_DIR/linux-build.sh" ]; then
    bash "$ROOT_DIR/linux-build.sh"
  else
    err "linux-build.sh não encontrado"
    exit 1
  fi
}

try_chroot(){
  command -v chroot >/dev/null 2>&1 || return 1
  [ "$(id -u)" = "0" ] || return 1
  [ -n "${GENERIC_CHROOT_ROOT:-}" ] || return 1
  [ -d "$GENERIC_CHROOT_ROOT" ] || return 1
  info "Modo CHROOT: $GENERIC_CHROOT_ROOT"
  mount --bind "$ROOT_DIR" "$GENERIC_CHROOT_ROOT/project" 2>/dev/null || true
  chroot "$GENERIC_CHROOT_ROOT" /bin/bash -lc 'cd /project && bash linux-build.sh'
}

try_chroot_distro(){
  command -v chroot-distro >/dev/null 2>&1 || return 1
  info "Modo CHROOT via chroot-distro"
  # Usa a distro configurada; se não houver, não força uma instalação silenciosa.
  local distro="${CHROOT_DISTRO:-debian}"
  chroot-distro status "$distro" >/dev/null 2>&1 || return 1
  chroot-distro login "$distro" -- /bin/bash -lc "cd '$ROOT_DIR' && bash linux-build.sh"
}

try_proot(){
  if command -v proot-distro >/dev/null 2>&1; then
    local distro="${PROOT_DISTRO:-debian}"
    info "Modo PRoot via proot-distro ($distro)"
    if ! proot-distro login "$distro" -- /bin/bash -lc "cd '$ROOT_DIR' && bash linux-build.sh"; then
      return 1
    fi
    return 0
  fi
  if command -v proot >/dev/null 2>&1; then
    warn "proot encontrado, mas nenhum rootfs foi configurado."
    warn "Defina GENERIC_ROOTFS para um rootfs Linux ARM64."
    [ -n "${GENERIC_ROOTFS:-}" ] && [ -d "$GENERIC_ROOTFS" ] || return 1
    proot -0 -r "$GENERIC_ROOTFS" -b /dev -b /proc -b /sys -b "$ROOT_DIR:/project" /bin/bash -lc 'cd /project && bash linux-build.sh'
    return $?
  fi
  return 1
}

case "$MODE" in
  auto)
    if try_chroot; then ok "Build concluído em CHROOT"; exit 0; fi
    if try_chroot_distro; then ok "Build concluído em CHROOT"; exit 0; fi
    warn "CHROOT indisponível; usando PRoot."
    if try_proot; then ok "Build concluído em PRoot"; exit 0; fi
    err "Nenhum ambiente CHROOT/PRoot utilizável foi encontrado."
    err "Instale proot-distro ou configure GENERIC_ROOTFS."
    exit 1
    ;;
  chroot)
    if try_chroot || try_chroot_distro; then ok "Build concluído em CHROOT"; else err "CHROOT indisponível."; exit 1; fi
    ;;
  proot)
    if try_proot; then ok "Build concluído em PRoot"; else err "PRoot indisponível."; exit 1; fi
    ;;
  *)
    err "Modo inválido: $MODE"
    exit 2
    ;;
esac
