#!/usr/bin/env bash
set -u
R="$(cd "$(dirname "$0")/.."&&pwd)";source "$R/scripts/common.sh";mkdir -p "$R/.cache";S="$R/.cache/WebView2"
[ -f "$S/build/native/include/WebView2.h" ]&&exit 0
F="$R/.cache/webview2.zip";download "https://www.nuget.org/api/v2/package/Microsoft.Web.WebView2/$WEBVIEW2_VERSION" "$F";rm -rf "$S";mkdir -p "$S";unzip -q "$F" -d "$S";H="$R/.cache/llvm-mingw/generic-w64-mingw32/include";[ -f "$H/eventtoken.h" ]&&[ ! -f "$H/EventToken.h" ]&&cp "$H/eventtoken.h" "$H/EventToken.h";ok 'WebView2 SDK pronto'
