#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.."&&pwd)";source "$ROOT/build.prop"
source "$ROOT/scripts/detect-arch.sh"
die(){ printf '\033[1;31m✖ %s\033[0m\n' "$*";exit 1;};ok(){ printf '\033[1;32m✔ %s\033[0m\n' "$*";};arch_info(){ printf '\033[1;35m▸ Host architecture: %s | Native Windows target: %s\033[0m\n' "$HOST_ARCH" "${NATIVE_TRIPLET:-unavailable}"; }
info(){ printf '\033[1;36m➜ %s\033[0m\n' "$*";}
download(){ command -v curl>/dev/null&&curl -fL --retry 3 -o "$2" "$1"&&return;command -v wget>/dev/null&&wget -O "$2" "$1"&&return;die 'curl/wget ausente';}
