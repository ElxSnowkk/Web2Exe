#!/usr/bin/env bash
set -euo pipefail
m="$(uname -m)"
case "$m" in
  x86_64|amd64) HOST_ARCH=x64; NATIVE_TRIPLET=x86_64-w64-mingw32 ;;
  i386|i486|i586|i686|x86) HOST_ARCH=x86; NATIVE_TRIPLET=i686-w64-mingw32 ;;
  aarch64|arm64) HOST_ARCH=arm64; NATIVE_TRIPLET=aarch64-w64-mingw32 ;;
  armv7l|armv8l) HOST_ARCH=arm32; NATIVE_TRIPLET= ;;
  *) HOST_ARCH=unknown; NATIVE_TRIPLET= ;;
esac
export HOST_ARCH NATIVE_TRIPLET
