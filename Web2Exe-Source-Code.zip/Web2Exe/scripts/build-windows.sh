#!/usr/bin/env bash
set -euo pipefail
R="$(cd "$(dirname "$0")/.." && pwd)"
source "$R/scripts/common.sh"
T="$R/.cache/llvm-mingw"
S="$R/.cache/WebView2"

arch_info
case "$HOST_ARCH" in
  x86|x64|arm64) info "Host detectado: $HOST_ARCH ($NATIVE_TRIPLET)" ;;
  *) die "Arquitetura do host não suportada: $(uname -m). Suportadas: x86_64, x86, aarch64/arm64." ;;
esac

# O host só define qual pacote LLVM-MinGW será baixado.
# O build é SEMPRE universal e produz os três targets Windows.
TARGETS="${WINDOWS_TARGETS:-x86 x64 arm64}"
info "Build universal automático: $TARGETS"

rm -rf "$R/dist"
mkdir -p "$R/dist"

for A in $TARGETS; do
  case "$A" in
    x86) X=i686-w64-mingw32; W=x86 ;;
    x64) X=x86_64-w64-mingw32; W=x64 ;;
    arm64) X=aarch64-w64-mingw32; W=arm64 ;;
    *) die "target inválido: $A" ;;
  esac

  B="$R/build/$A"
  rm -rf "$B"
  mkdir -p "$B"
  cat > "$B/t.cmake" <<EOF2
set(CMAKE_SYSTEM_NAME Windows)
set(CMAKE_C_COMPILER "$T/bin/$X-clang")
set(CMAKE_CXX_COMPILER "$T/bin/$X-clang++")
set(WEBVIEW2_ROOT "$S" CACHE PATH "")
set(WEBVIEW2_ARCH "$W" CACHE STRING "")
EOF2

  cmake -S "$R" -B "$B" -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="$B/t.cmake" \
    -DCMAKE_BUILD_TYPE="$BUILD_TYPE"
  cmake --build "$B" --parallel

  mkdir -p "$R/dist/$A"
  cp "$B/app.exe" "$R/dist/$A/$APP_EXE_NAME.exe"
  cp "$S/build/native/$W/WebView2Loader.dll" "$R/dist/$A/"

  # Copy every MinGW/LLVM runtime DLL actually shipped by the selected toolchain.
  # This avoids missing libc++, libunwind, libc++abi, libwinpthread and future runtime pieces.
  for DLL in "$T/bin/$X"*.dll; do
    [ -f "$DLL" ] || continue
    cp "$DLL" "$R/dist/$A/"
  done
  [ -f "$R/assets/app.ico" ] && cp "$R/assets/app.ico" "$R/dist/$A/"
  ok "Windows $A"
done
