#!/usr/bin/env bash
set -u
R="$(cd "$(dirname "$0")/.."&&pwd)";source "$R/scripts/common.sh";mkdir -p "$R/.cache"
case "$(uname -m)" in aarch64|arm64)H=aarch64;;x86_64|amd64)H=x86_64;;*)die "Host não suportado";;esac
A="llvm-mingw-${LLVM_MINGW_VERSION}-ucrt-ubuntu-22.04-${H}.tar.xz";F="$R/.cache/$A"
download "https://github.com/mstorsjo/llvm-mingw/releases/download/$LLVM_MINGW_VERSION/$A" "$F";rm -rf "$R/.cache/llvm-mingw";mkdir -p "$R/.cache/llvm-mingw";tar -xJf "$F" -C "$R/.cache/llvm-mingw" --strip-components=1;ok 'LLVM-MinGW pronto'
