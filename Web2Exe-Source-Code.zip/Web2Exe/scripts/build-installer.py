from pathlib import Path
import subprocess

R = Path(__file__).resolve().parents[1]
exec((R / 'build.prop').read_text(), globals())
D = R / 'dist'
B = R / 'build' / 'installer'
B.mkdir(parents=True, exist_ok=True)

def byte_array(data, name):
    out = [f'static const unsigned char {name}[]={{']
    for i in range(0, len(data), 24):
        out.append(','.join(f'0x{x:02X}' for x in data[i:i+24]) + ',')
    out.append(f'}}; static const unsigned int {name}_size={len(data)}u;')
    return '\n'.join(out)

payloads = []
for arch in ('x86', 'x64', 'arm64'):
    folder = D / arch
    exe = folder / f'{APP_EXE_NAME}.exe'
    loader = folder / 'WebView2Loader.dll'
    if not exe.exists(): raise SystemExit(f'Ausente: {exe}')
    if not loader.exists(): raise SystemExit(f'Ausente: {loader}')
    files = [exe, loader] + sorted(folder.glob('*.dll'))
    seen = set()
    for p in files:
        if p.name in seen: continue
        seen.add(p.name)
        payloads.append((arch, p.name, p.read_bytes(), f'p_{arch}_{p.name.replace(".", "_").replace("+", "x")}'))

raw_arrays = '\n'.join(byte_array(data, var) for _, _, data, var in payloads)

list_decls = ''
for arch in ('x86', 'x64', 'arm64'):
    rows = [(fn, var) for a, fn, _, var in payloads if a == arch]
    entries = ','.join(f'{{L"{fn}",{var},{var}_size}}' for fn, var in rows)
    list_decls += f'\nstatic const Payload p_{arch}_list[]={{ {entries} }};\n'
    list_decls += f'static const unsigned p_{arch}_list_count={len(rows)}u;\n'

CPP = r'''#define UNICODE
#define _UNICODE
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <string>
__ARRAYS__
struct Payload { const wchar_t* name; const unsigned char* data; unsigned size; };
__LISTS__
static const GUID PF={0x905E63B6,0xC1BF,0x494E,{0xB2,0x9C,0x65,0xB7,0x32,0xD3,0xD2,0x1A}};
static const GUID CLS={0x00021401,0,0,{0xC0,0,0,0,0,0,0,0x46}};
static const GUID GD={0xB4BFCC3A,0xDB2C,0x424C,{0xB0,0x29,0x7F,0xE9,0x9A,0x87,0xC6,0x41}};
static const GUID GS={0x625B53C3,0xAB48,0x4EC1,{0xBA,0x1F,0xA1,0xEF,0x41,0x46,0xFC,0x19}};
static const GUID ISL={0x000214F9,0,0,{0xC0,0,0,0,0,0,0,0x46}};
static const GUID IPF={0x0000010B,0,0,{0xC0,0,0,0,0,0,0,0x46}};
static std::wstring known(const GUID& g){PWSTR p=nullptr;if(FAILED(SHGetKnownFolderPath(g,0,nullptr,&p)))return L"";std::wstring s=p;CoTaskMemFree(p);return s;}
static bool write_file(const std::wstring& p,const unsigned char* d,unsigned n){HANDLE h=CreateFileW(p.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);if(h==INVALID_HANDLE_VALUE)return false;DWORD z=0;BOOL q=WriteFile(h,d,n,&z,nullptr);CloseHandle(h);return q&&z==n;}
static void mkdirs(const std::wstring& p){for(size_t i=3;i<p.size();++i)if(p[i]==L'\\'){std::wstring q=p.substr(0,i);CreateDirectoryW(q.c_str(),nullptr);}CreateDirectoryW(p.c_str(),nullptr);}
static bool link_file(const std::wstring& l,const std::wstring& t,const std::wstring& w){IShellLinkW*s=nullptr;if(FAILED(CoCreateInstance(CLS,nullptr,CLSCTX_INPROC_SERVER,ISL,(void**)&s)))return false;s->SetPath(t.c_str());s->SetWorkingDirectory(w.c_str());IPersistFile*p=nullptr;bool q=SUCCEEDED(s->QueryInterface(IPF,(void**)&p));if(q){q=SUCCEEDED(p->Save(l.c_str(),TRUE));p->Release();}s->Release();return q;}
int WINAPI wWinMain(HINSTANCE,HINSTANCE,PWSTR,int){CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);SYSTEM_INFO si{};GetNativeSystemInfo(&si);const Payload* list=nullptr;unsigned count=0;if(si.wProcessorArchitecture==PROCESSOR_ARCHITECTURE_ARM64){list=p_arm64_list;count=p_arm64_list_count;}else if(si.wProcessorArchitecture==PROCESSOR_ARCHITECTURE_AMD64){list=p_x64_list;count=p_x64_list_count;}else{list=p_x86_list;count=p_x86_list_count;}PWSTR pf=nullptr;if(FAILED(SHGetKnownFolderPath(PF,0,nullptr,&pf)))return 1;std::wstring base=std::wstring(pf)+L"\\__INSTALL__";CoTaskMemFree(pf);mkdirs(base);std::wstring exe;for(unsigned i=0;i<count;++i){std::wstring out=base+L"\\"+list[i].name;if(!write_file(out,list[i].data,list[i].size)){MessageBoxW(nullptr,L"Falha ao instalar um arquivo.",L"__NAME__",MB_OK|MB_ICONERROR);CoUninitialize();return 2;}if(std::wstring(list[i].name)==L"__EXE__.exe")exe=out;}std::wstring programs=known(GS)+L"\\Programs",sm=programs+L"\\__NAME__";mkdirs(sm);link_file(sm+L"\\__NAME__.lnk",exe,base);link_file(known(GD)+L"\\__NAME__.lnk",exe,base);MessageBoxW(nullptr,L"__NAME__ foi instalado com sucesso.",L"__NAME__",MB_OK|MB_ICONINFORMATION);ShellExecuteW(nullptr,L"open",exe.c_str(),nullptr,nullptr,SW_SHOWNORMAL);CoUninitialize();return 0;}
'''
CPP = CPP.replace('__ARRAYS__', raw_arrays).replace('__LISTS__', list_decls).replace('__NAME__', APP_NAME).replace('__EXE__', APP_EXE_NAME).replace('__INSTALL__', INSTALL_DIR)
source = B / 'setup.cpp'
source.write_text(CPP)
compiler = R / '.cache/llvm-mingw/bin/i686-w64-mingw32-clang++'
out = D / f'{APP_EXE_NAME}-Setup.exe'
subprocess.run([str(compiler), '-std=c++17', '-O2', '-municode', '-mwindows', str(source), '-o', str(out), '-lshell32', '-lole32', '-ladvapi32'], check=True)
print(out)
