from pathlib import Path
import shlex
r=Path(__file__).resolve().parents[1];v={}
for x in (r/'build.prop').read_text().splitlines():
 x=x.strip()
 if x and not x.startswith('#') and '=' in x:
  k,z=x.split('=',1);v[k]=shlex.split(z)[0]
s=(r/'src/config.hpp').read_text()
for k in ('APP_NAME','APP_URL'):s=s.replace('__'+k+'__',v[k].replace('\\','\\\\').replace('"','\\"'))
(r/'build').mkdir(exist_ok=True);(r/'build/config.hpp').write_text(s)
