# Generic WebView2 App Builder

Configure only `build.prop` and put your logo in `assets/logo.png` (optional `assets/app.ico`).

### Termux ARM64
`bash termux-proot/chroot.sh`

The script tries a usable chroot first, then automatically falls back to PRoot; root is not required.

### Normal Linux
`bash linux-build.sh`

No PRoot/chroot is used. It detects host architecture and distribution. It downloads LLVM-MinGW automatically when needed. Windows PE targets necessarily require a Windows cross toolchain; the script hides that complexity.

### Output
`dist/<APP_EXE_NAME>-Setup.exe` contains x86, x64 and ARM64 payloads and selects the native one at install time.

WebView2 Runtime is an external Windows dependency.


## Runtime LLVM-MinGW embutido

O builder copia automaticamente para cada target as DLLs de runtime encontradas no toolchain, incluindo `libc++.dll`, `libunwind.dll`, `libc++abi.dll` e `libwinpthread-1.dll` quando existirem. O `Setup.exe` também embute essas DLLs junto do EXE e do `WebView2Loader.dll`, evitando o erro `c0000135` causado por runtime ausente.


## Arquitetura

O builder detecta `uname -m` antes da compilação:

- `x86_64`/`amd64` → alvo nativo Windows x64
- `i686`/`x86` → alvo nativo Windows x86
- `aarch64`/`arm64` → alvo nativo Windows ARM64

 compila somente o alvo correspondente ao host. Sem , o builder mantém a geração universal x86 + x64 + ARM64.

Exemplos:

```bash
web2exe --linux
web2exe --termux --proot
```

Observação: em Linux/Termux o C++ Windows ainda precisa do LLVM-MinGW, porque o compilador nativo do Linux gera ELF Linux, não PE/Windows. O detecção automática do host aqui significa selecionar automaticamente o alvo Windows correspondente à arquitetura da máquina, sem exigir configuração manual de cross-compiler.


### Build universal automático
O Web2Exe detecta a arquitetura do host apenas para escolher o pacote LLVM-MinGW compatível. O resultado é sempre universal: x86, x64 e ARM64. Não há opção para escolher arquitetura manualmente. O instalador universal embute o EXE e todas as DLLs de cada arquitetura e seleciona o conjunto correto no Windows.
