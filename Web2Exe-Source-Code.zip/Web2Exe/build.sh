#!/data/data/com.termux/files/usr/bin/bash
set -e
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
exec bash "$ROOT_DIR/termux-proot/proot.sh" "$@"
