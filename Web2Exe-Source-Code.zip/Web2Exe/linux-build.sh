#!/usr/bin/env bash
set -euo pipefail
R="$(cd "$(dirname "$0")" && pwd)"
source "$R/scripts/common.sh"

printf '\n\033[1;35m╔══════════════════════════════════════════════════════╗\033[0m\n'
printf '\033[1;35m║ GENERIC WEBVIEW2 BUILDER • LINUX                   ║\033[0m\n'
printf '\033[1;35m╚══════════════════════════════════════════════════════╝\033[0m\n'
arch_info

command -v cmake >/dev/null || die 'CMake ausente'
command -v ninja >/dev/null || die 'Ninja ausente'
command -v python3 >/dev/null || die 'Python3 ausente'

mkdir -p "$R/build"
python3 "$R/scripts/render-config.py"
[ -x "$R/.cache/llvm-mingw/bin/i686-w64-mingw32-clang++" ] || bash "$R/scripts/get-toolchain.sh"
[ -f "$R/.cache/WebView2/build/native/include/WebView2.h" ] || bash "$R/scripts/get-webview2.sh"

[ "$#" -eq 0 ] || die "O build Linux é universal e não aceita seleção manual de arquitetura."
bash "$R/scripts/build-windows.sh"
python3 "$R/scripts/build-installer.py"
printf '\n\033[1;32m✔ BUILD CONCLUÍDO\033[0m\nInstaller: %s/dist/%s-Setup.exe\n' "$R" "$APP_EXE_NAME"
